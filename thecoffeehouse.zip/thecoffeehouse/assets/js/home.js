$(document).ready(function() {
  $('.hero-slider').slick();
});